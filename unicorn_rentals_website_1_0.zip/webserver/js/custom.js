/*Theme    : Quick
 * Author  : Design_mylife
 * Version : V1.0
 *
 */


// ***********************************
// Backstretch - Slider on Background
// ***********************************

$("body").backstretch([
   "/img/bg-image-6.jpg",
   "/img/bg-image-5.jpg",
   "/img/bg-image-4.jpg",
   "/img/bg-image-3.jpg"
], {duration: 8000, fade: 1000});
